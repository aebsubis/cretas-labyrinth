package gui;

public class GUISaveGame {

}
