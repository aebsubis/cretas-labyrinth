package gui;

public class GUISettings {

}
