package gui;

public class GUIInventory {

}
